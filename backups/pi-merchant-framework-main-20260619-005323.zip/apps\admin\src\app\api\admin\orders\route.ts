import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import type { Prisma } from '@prisma/client';
import { getMerchantId } from '@/lib/utils';
import { cookies } from 'next/headers';
import { verifySessionToken } from '@/lib/session';
import { withMetrics } from '@/lib/metrics-middleware';

async function __GET(req: Request) {
  const token = cookies().get('pi_auth_token')?.value;
  if (!token || !verifySessionToken(token))
    return NextResponse.json({ orders: [], pagination: null });

  const { searchParams } = new URL(req.url);
  const statusParam = searchParams.get('status');
  const pageParam = searchParams.get('page');
  const limitParam = searchParams.get('limit');

  const page = pageParam ? Math.max(1, parseInt(pageParam)) : 1;
  const limit = limitParam ? Math.min(100, Math.max(1, parseInt(limitParam))) : 10;

  const merchantId = getMerchantId();
  const where: any = { merchantId };

  if (statusParam && statusParam !== 'ALL') {
    // statusParam comes from query string (string). Prisma expects the enum type `OrderStatus` or a filter.
    // Cast to `OrderStatus` to satisfy the type system while preserving existing behaviour.
    const status = statusParam as any;
    where.status = status;
  }

  try {
    const total = await prisma.order.count({ where });
    const orders = await prisma.order.findMany({
      where,
      include: {
        customer: { select: { username: true } },
        service: { select: { title: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
    });

    return NextResponse.json({
      orders,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit) || 1,
      },
    });
  } catch (_e) {
    return NextResponse.json({ orders: [], pagination: null });
  }
}

export const GET = withMetrics(__GET);
